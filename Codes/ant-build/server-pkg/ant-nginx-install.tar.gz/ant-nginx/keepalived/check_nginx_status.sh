#!/bin/bash 

if [ "$(systemctl status whale-nginx | grep 'Active: ' | cut -f2 | awk '{ print $2}')" == "inactive" ]; then
    exit 1
fi
exit 0