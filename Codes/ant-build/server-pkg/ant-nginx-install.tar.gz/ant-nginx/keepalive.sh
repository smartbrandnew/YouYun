#!/bin/bash

CURRENT_DIR=$(cd "$(dirname "$0")"; pwd)
cd $CURRENT_DIR

REAL_SRV=localhost
VIP=localhost

while getopts "r:v:" args; do
    case $args in
        r)
            REAL_SRV=$OPTARG
            ;;
        v)
            VIP=$OPTARG
            ;;
        ?)
            echo "Invalid parameter"
            ;;
    esac
done

print_info() {
    echo -e "\033[30;32;1m$1 \033[0m"
}

print_error() {
    echo -e "\033[30;31;1m$1 \033[0m"
}

set_env() {
    \cp $CURRENT_DIR/keepalived/ip_vs.modules /etc/sysconfig/modules/
    chmod 755 /etc/sysconfig/modules/ip_vs.modules
    modprobe ip_vs

    sed -i "/net.ipv4.ip_forward/d" /etc/sysctl.conf
    sed -i "/net.ipv4.ip_nonlocal_bind/d" /etc/sysctl.conf
    sed -i "/net.ipv4.conf.all.arp_ignore/d" /etc/sysctl.conf
    sed -i "/net.ipv4.conf.all.arp_announce/d" /etc/sysctl.conf
    sed -i "/net.ipv4.conf.lo.arp_ignore/d" /etc/sysctl.conf
    sed -i "/net.ipv4.conf.lo.arp_announce/d" /etc/sysctl.conf
    
    echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
    echo "net.ipv4.ip_nonlocal_bind = 1" >> /etc/sysctl.conf
    echo "net.ipv4.conf.all.arp_ignore = 1" >> /etc/sysctl.conf
    echo "net.ipv4.conf.all.arp_announce = 2" >> /etc/sysctl.conf
    echo "net.ipv4.conf.lo.arp_ignore = 1" >> /etc/sysctl.conf
    echo "net.ipv4.conf.lo.arp_announce = 2" >> /etc/sysctl.conf

    sysctl -p
}

uninstall() {
    print_info "Check whether keepalived-nginx has been installed, if there is to uninstall."
    if [ -e "/usr/lib/systemd/system/keepalived-nginx.service" ]; then 
        systemctl stop keepalived-nginx 
    fi
    rm -rf /var/run/keepalived_nginx
    rm -rf /etc/keepalived/keepalived_nginx.conf
}

install() {
    print_info "Unpack keepalived package and install....."
    rpm -iv $CURRENT_DIR/repos/libnl-1.1.4-3.el7.x86_64.rpm
    tar -zxf $CURRENT_DIR/keepalived/keepalived.tar.gz -C /opt/

    mkdir -p /etc/keepalived
    \cp /opt/keepalived/etc/sysconfig/keepalived /etc/sysconfig/
    \cp $CURRENT_DIR/keepalived/keepalived_nginx.conf /etc/keepalived/
    \cp $CURRENT_DIR/keepalived/check_nginx_status.sh /opt/keepalived/sbin
    if [ ! -e "/usr/lib/systemd/system/keepalived-nginx.service" ]; then 
        \cp $CURRENT_DIR/keepalived/keepalived-nginx.service /usr/lib/systemd/system
    fi
    
    mkdir -p /var/run/keepalived_nginx
    ln -s /opt/keepalived/sbin/keepalived /usr/sbin
    chmod -R 755 /opt/keepalived/sbin/check_nginx_status.sh
    systemctl enable keepalived-nginx.service
    systemctl daemon-reload
}

configure() {
    print_info "Configure keepalived_nginx.conf file....."
    
    router_id=${VIP##*.}
    sed -i "s/ROUTER_ID/$router_id/g" /etc/keepalived/keepalived_nginx.conf

    # NIC list
    nics=$(ls /sys/class/net)
    for nic in $nics
    do
        ip_arr=$(ip addr show $nic | grep $REAL_SRV | grep 'inet ' | cut -f2 | awk '{ print $2}' | awk -F "/" '{ print $1}')
        if [[ "${ip_arr[@]}" =~ "$REAL_SRV" ]]; then
            subnet=$(ip addr show $nic | grep $REAL_SRV | grep 'inet ' | cut -f2 | awk '{ print $2}' | awk -F "/" '{ print $2}')
            brd=$(ip addr show $nic | grep $REAL_SRV | grep 'inet ' | cut -f2 | awk '{ print $4}')
            scope=$(ip addr show $nic | grep $REAL_SRV | grep 'inet ' | cut -f2 | awk '{ print $6}')

            sed -i "s/VIP_ADDR/$VIP\/$subnet brd $brd dev $nic scope $scope label $nic:$router_id/g" /etc/keepalived/keepalived_nginx.conf
            sed -i "s/NIC/$nic/g" /etc/keepalived/keepalived_nginx.conf
        fi
    done
}

if [[ $# -ne 4 ]]; then
    echo "USAGE: sh keepalive.sh -r 10.1.241.53 -v 10.1.241.77"
    echo "-r: Real Server IP"
    echo "-v: VIP"
else
    set_env
    uninstall
        
    install
    if [ $? -ne 0 ]; then
        print_error "Install keepalived-nginx failure!"
    fi
        
    configure
    if [ $? -ne 0 ]; then
        print_error "Configure keepalived-nginx failure!"
    fi

    systemctl start keepalived-nginx
    if [ $? -ne 0 ]; then
        print_error "Start keepalived-mysql failure!"
    else
        print_info "Start keepalived-nginx success!"
    fi
fi
