#!/bin/bash

green() {
    echo -e "\033[30;32;1m$1 \033[0m"
}

red() {
    echo -e "\033[30;31;1m$1 \033[0m"
}

green "Prepare to install nginx"
if [ -n "$(ps aux | grep install_base/nginx | grep -v grep)" ];then
    install_base/nginx/sbin/nginx -s stop
fi

groupadd -r nginx
useradd -s /sbin/nologin -g nginx -r nginx

rm -rf install_base/nginx
tar -zxf ./nginx/nginx-1.8.1.bin.tar.gz -C install_base
\cp -rf nginx.conf install_base/nginx/conf
green "Nginx Installation is complete"

mkdir -p server_file_dir

green "Nginx starting ..."
\cp ./nginx/uyun-ant-nginx.service /usr/lib/systemd/system
systemctl enable uyun-ant-nginx.service
systemctl daemon-reload
systemctl start uyun-ant-nginx
