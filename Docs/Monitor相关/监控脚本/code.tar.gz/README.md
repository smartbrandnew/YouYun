运行步骤：
1.将所有文件上传到某文件夹
2.解压绿色python到/opt: tar zxf fabric.tar.gz -C /opt/
3.cd 到代码所在的目录下，填写好host.yaml文件
4.host.yaml里面需填写一下hostname，就是安装agent的hostname,os是显示的tag, api_key暂时在代码中写死
5.执行脚本: /opt/fabric/bin/python /opt/fabric/bin/fab -f test_install.py test_install_agent
