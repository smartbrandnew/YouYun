# !/opt/python/bin/python
# -*- coding:utf-8 -*-
# notice: to enable env.passwords, host must beuser@ip:port, port must be written explicitly 

from fabric.api import *
from fabric.context_managers import *
import yaml

hosts = []
passwords = {}
ip_hostname = {}
ip_os = {}

host_list = yaml.load(file('host.yaml', 'r'))["hosts_list"]
for host_detail in host_list:
    host = "%s@%s:%s" %(host_detail["user"], host_detail["ip"], host_detail["port"])
    password = host_detail["password"]
    hosts.append(host)
    passwords[host] = password
    ip_hostname[host_detail["ip"]] = host_detail["hostname"]
    ip_os[host_detail["ip"]] = host_detail["os"]

env.passwords = passwords
env.roledefs = {'install_agent': hosts}

@roles('install_agent')
def test_install_agent():
    try:
        ip = run("/sbin/ifconfig -a|grep inet|grep -v 127.0.0.1|grep -v inet6|awk '{print $2}'|tr -d 'addr:'")
        ip = ip[:15].strip("\r\n")
        hostname = ip_hostname[ip]
        os = ip_os[ip]
        key = "86830b460bd64cce990def8a357c38fd" 
        url = "https://monitor.uyuntest.cn"
        install_agent_cmd = 'HOSTNAME="%s" DD_API_KEY=%s TAGS="%s:monitor" REPERTORY_URL="%s" bash -c "$(curl -L https://monitor.uyuntest.cn/downloads/agent/install_agent.sh)"' %(hostname, key, os, url)
        run(install_agent_cmd)
    except Exception,e:
        print e
